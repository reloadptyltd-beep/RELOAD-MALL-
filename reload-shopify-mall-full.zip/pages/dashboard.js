import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import TaskCard from '../components/TaskCard';
import BalanceCard from '../components/BalanceCard';
import { useRouter } from 'next/router';

export default function Dashboard(){
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [balance, setBalance] = useState(0);
  const [tasks, setTasks] = useState([]);

  useEffect(()=>{
    const fetch = async () => {
      const { data: session } = await supabase.auth.getUser();
      if (!session?.user) { router.push('/'); return; }
      setUser(session.user);

      const { data } = await supabase
        .from('users')
        .select('id,balance_cents')
        .eq('email', session.user.email)
        .single();
      if (data) setBalance(Math.round(data.balance_cents/100));

      const tasksRes = await supabase.from('task_orders').select('*').order('id', { ascending: true }).limit(8);
      if (tasksRes.data) {
        setTasks(tasksRes.data.map(t => ({
          id: t.id,
          order_number: t.order_number,
          image: t.image_url || 'https://via.placeholder.com/150',
          order_total: (t.order_total_cents/100).toFixed(2),
          price: (t.price_cents/100).toFixed(2),
          commission: (t.commission_cents/100).toFixed(2),
          completed: t.completed
        })));
      }
    }
    fetch();
  }, []);

  const handleTaskComplete = async (taskId, commission) => {
    await supabase.from('task_orders').update({ completed: true, completed_at: new Date() }).eq('id', taskId);
    const { data: userRow } = await supabase.from('users').select('id,balance_cents').eq('email', user.email).single();
    if (userRow) {
      await supabase.from('users').update({ balance_cents: userRow.balance_cents + Math.round(commission*100) }).eq('id', userRow.id);
      setBalance(prev => prev + commission);
    }
    setTasks(prev => prev.map(t => t.id === taskId ? {...t, completed:true} : t));
  }

  const logout = async () => {
    await supabase.auth.signOut();
    router.push('/');
  }

  return (
    <div style={{padding:20, fontFamily:'Arial'}}>
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <h1>Reload Shopify Mall</h1>
        <div>
          <button onClick={()=>router.push('/withdraw')} style={{marginRight:8}}>Withdraw</button>
          <button onClick={logout}>Logout</button>
        </div>
      </header>

      <BalanceCard balance={balance} />

      <h2>Available Task Orders</h2>
      <div>
        {tasks.length === 0 && <p>No task orders yet.</p>}
        {tasks.map(t => (
          <TaskCard
            key={t.id}
            task={t}
            onComplete={() => handleTaskComplete(t.id, parseFloat(t.commission))}
          />
        ))}
      </div>
    </div>
  )
}
