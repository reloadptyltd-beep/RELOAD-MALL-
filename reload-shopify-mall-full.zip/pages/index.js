import { useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../lib/supabaseClient';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');

  const handleLogin = async () => {
    if (!email) return alert('Enter your email');
    const { error } = await supabase.auth.signInWithOtp({ email });
    if (error) return alert(error.message);
    alert('Check your email for a login link (magic link).');
  }

  return (
    <div style={{padding:20, fontFamily:'Arial'}}>
      <h1>Reload Shopify Mall</h1>
      <p>Sign in with your email</p>
      <input style={{padding:8,width:'100%'}} value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" />
      <div style={{marginTop:12}}>
        <button onClick={handleLogin} style={{padding:'8px 16px'}}>Send Magic Link</button>
      </div>
    </div>
  )
}
