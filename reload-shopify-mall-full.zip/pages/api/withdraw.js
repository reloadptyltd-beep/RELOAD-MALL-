export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  try {
    const body = req.body;

    if (!body || !body.user_id || !body.amount_cents || !body.method) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const EDGE_FUNCTION_URL = process.env.EDGE_FUNCTION_URL;
    if (!EDGE_FUNCTION_URL) return res.status(500).json({ error: 'Edge function URL not configured' });

    const response = await fetch(EDGE_FUNCTION_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    const data = await response.json();
    if (!response.ok) return res.status(500).json({ error: data });

    return res.status(200).json(data);
  } catch (err) {
    return res.status(500).json({ error: err.message || 'Server error' });
  }
}
