import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useRouter } from 'next/router';

export default function Withdraw(){
  const [method, setMethod] = useState('EFT');
  const [amount, setAmount] = useState('');
  const [bankName, setBankName] = useState('');
  const [branchCode, setBranchCode] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [balance, setBalance] = useState(0);
  const router = useRouter();

  useEffect(()=>{
    (async ()=>{
      const { data: session } = await supabase.auth.getUser();
      if(!session?.user) { router.push('/'); return; }
      const { data } = await supabase.from('users').select('balance_cents').eq('email', session.user.email).single();
      if (data) setBalance(Math.round(data.balance_cents/100));
    })()
  },[]);

  const submit = async () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return alert('Enter amount');
    if (amt > balance) return alert('Insufficient balance');

    const { data: session } = await supabase.auth.getUser();
    const payload = {
      user_id: session.user.id,
      amount_cents: Math.round(amt*100),
      method,
      destination: method === 'EFT' ? JSON.stringify({ bankName, branchCode, accountNumber }) : ''
    }

    const res = await fetch('/api/withdraw', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const j = await res.json();
    if (!res.ok) return alert('Withdraw failed: ' + (j?.error || JSON.stringify(j)));
    alert('Withdrawal requested. Status: ' + (j?.message || 'processing'));
    router.push('/dashboard');
  }

  return (
    <div style={{padding:20, fontFamily:'Arial'}}>
      <h1>Withdraw — Reload Shopify Mall</h1>
      <p>Available Balance: R{balance}</p>

      <div style={{marginTop:12}}>
        <label>Method</label><br/>
        <select value={method} onChange={e=>setMethod(e.target.value)}>
          <option>EFT</option>
          <option>USDT</option>
          <option>TRC20</option>
          <option>Skrill</option>
        </select>
      </div>

      {method === 'EFT' && (
        <div style={{marginTop:8}}>
          <input placeholder="Bank Name" value={bankName} onChange={e=>setBankName(e.target.value)} /><br/>
          <input placeholder="Branch Code" value={branchCode} onChange={e=>setBranchCode(e.target.value)} /><br/>
          <input placeholder="Account Number" value={accountNumber} onChange={e=>setAccountNumber(e.target.value)} /><br/>
        </div>
      )}

      <div style={{marginTop:8}}>
        <input placeholder="Amount (R)" value={amount} onChange={e=>setAmount(e.target.value)} />
      </div>

      <div style={{marginTop:12}}>
        <button onClick={submit}>Request Withdrawal</button>
      </div>
    </div>
  )
}
