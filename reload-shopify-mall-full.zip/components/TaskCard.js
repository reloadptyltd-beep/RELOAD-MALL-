import { useState } from 'react';

export default function TaskCard({ task, onComplete }) {
  const [busy, setBusy] = useState(false);
  const [countdown, setCountdown] = useState(0);

  const handle = () => {
    if (busy) return;
    setBusy(true);
    setCountdown(30);
    const intv = setInterval(()=>{
      setCountdown(c => {
        if (c <= 1) {
          clearInterval(intv);
          setBusy(false);
          onComplete();
          return 0;
        }
        return c - 1;
      });
    }, 1000);
  }

  return (
    <div style={{border:'1px solid #ddd', padding:12, marginBottom:8, display:'flex', gap:12}}>
      <img src={task.image} width={100} height={100} alt='product' />
      <div style={{flex:1}}>
        <div>Order #{task.order_number}</div>
        <div>Total: R{task.order_total}</div>
        <div>Commission: R{task.commission}</div>
      </div>
      <div>
        <button onClick={handle} disabled={task.completed || busy}>
          {busy ? `Completing ${countdown}s` : (task.completed ? 'Completed' : 'Complete')}
        </button>
      </div>
    </div>
  )
}
