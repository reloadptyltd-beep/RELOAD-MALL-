export default function BalanceCard({ balance }) {
  return (
    <div style={{border:'1px solid #0b7', padding:12, margin:'12px 0'}}>
      <strong>Available balance:</strong> R{balance}
    </div>
  );
}
