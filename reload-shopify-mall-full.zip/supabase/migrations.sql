-- users
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  full_name text,
  email text unique,
  balance_cents bigint default 200000,
  created_at timestamptz default now()
);

-- task_orders
create table if not exists task_orders (
  id serial primary key,
  time_slot timestamptz not null,
  order_number int not null,
  image_url text,
  order_total_cents bigint not null,
  price_cents bigint not null,
  commission_cents bigint not null,
  completed boolean default false,
  completed_at timestamptz
);

-- withdrawals
create table if not exists withdrawals (
  id serial primary key,
  user_id uuid references users(id),
  amount_cents bigint not null,
  method text not null,
  bank_name text,
  branch_code text,
  account_number text,
  destination text,
  status text default 'requested',
  created_at timestamptz default now()
);
