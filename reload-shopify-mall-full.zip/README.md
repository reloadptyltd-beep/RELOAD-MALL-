# Reload Shopify Mall

Full starter app (Next.js + Supabase) for Reload Shopify Mall.

## Deploy steps (short)

1. Create a new GitHub repository named `reload-shopify-mall` and push these files.
2. In Supabase: create tables (see `supabase/migrations.sql`) and Edge Function is already deployed.
3. In Netlify/Vercel set environment variables listed in `.env.example`.
4. Connect the GitHub repo to Netlify (New site from Git). Build command: `npm run build`, publish dir: `.next`
5. Visit the site, sign in with email (magic link), test dashboard, complete tasks, and request withdrawals.

